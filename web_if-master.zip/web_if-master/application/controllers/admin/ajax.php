<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Ajax extends CI_Controller {
	private $_cpmask = 32;
	
	public function index($idAlbum = -1) {
		echo "Hello!";
	}
}