<select class='menu_mini'>
	<option class='menu_unit' value='#'>- Navigasi -</option>
	<option class='menu_unit' value='http://if.undip.ac.id/'>Home</option>
	<option class='menu_unit' value='#'>Profil</option>
	<option class='menu_unit' value='http://if.undip.ac.id/page/sejarah'>-- Sejarah</option>
	<option class='menu_unit' value='http://if.undip.ac.id/page/visi-misi'>-- Visi-misi</option>
	<option class='menu_unit' value='http://if.undip.ac.id/page/pimpinan'>-- Pimpinan</option>
	<option class='menu_unit' value='http://if.undip.ac.id/staff'>-- Staff</option>
	<option class='menu_unit' value='http://if.undip.ac.id/penelitian'>-- Penelitian</option>
	<option class='menu_unit' value='http://if.undip.ac.id/pengabdian'>-- Pengabdian</option>
	<option class='menu_unit' value='http://if.undip.ac.id/page/kerjasama'>-- Kerjasama</option>
	<option class='menu_unit' value='#'>Akademik</option>
	<option class='menu_unit' value='http://if.undip.ac.id/page/peraturan-akademik'>-- Peraturan Akademik</option>
	<option class='menu_unit' value='http://if.undip.ac.id/page/manual-prosedur'>-- Manual Prosedur</option>
	<option class='menu_unit' value='http://if.undip.ac.id/page/kalender-akademik'>-- Kalender Akademik</option>
	<option class='menu_unit' value='http://if.undip.ac.id/kurikulum'>-- Kurikulum</option>
	<option class='menu_unit' value='http://if.undip.ac.id/page/jadwal-kuliah'>-- Jadwal Kuliah</option>
	<option class='menu_unit' value='#'>Fasilitas</option>
	<option class='menu_unit' value='http://if.undip.ac.id/page/lab-riset'>-- Laboratorium Riset</option>
	<option class='menu_unit' value='http://if.undip.ac.id/page/lab-layanan'>-- Laboratorium Layanan</option>
	<option class='menu_unit' value='http://if.undip.ac.id/page/sarana-it'>-- Sarana IT</option>
	<option class='menu_unit' value='http://if.undip.ac.id/page/fasilitas-olahraga'>-- Fasilitas Olahraga</option>
	<option class='menu_unit' value='http://if.undip.ac.id/page/sarana-umum'>-- Sarana Umum</option>
	<option class='menu_unit' value='#'>Kemahasiswaan</option>
	<option class='menu_unit' value='http://if.undip.ac.id/page/prestasi-mahasiswa'>-- Prestasi Mahasiswa</option>
	<option class='menu_unit' value='http://hm.if.undip.ac.id'>-- Himpunan Mahasiswa</option>
	<option class='menu_unit' value='http://forum.if.undip.ac.id'>-- Forum Mahasiswa</option>
	<option class='menu_unit' value='http://if.undip.ac.id/page/biro-komunitas'>-- Biro dan Komunitas</option>
	<option class='menu_unit' value='#'>-- Himpunan Alumni</option>
	<option class='menu_unit' value='http://if.undip.ac.id/news'>Berita</option>
	<option class='menu_unit' value='http://if.undip.ac.id/news?cat=1'>-- Akademik</option>
	<option class='menu_unit' value='http://if.undip.ac.id/agenda'>-- Agenda</option>
	<option class='menu_unit' value='http://if.undip.ac.id/news?cat=3'>-- Lowongan</option>
	<option class='menu_unit' value='http://if.undip.ac.id/galeri'>Galeri</option>
	<option class='menu_unit' value='http://if.undip.ac.id/page/kontak'>Kontak</option>
</select>

<ul class='menu'>
	<li><a href='http://if.undip.ac.id/'><span>Home</span></a>
	</li>
	<li class='parent'><a href='#'><span>Profil</span></a>
		<div><ul><li><a href='http://if.undip.ac.id/page/sejarah'><span>Sejarah</span></a>
				</li>
				<li><a href='http://if.undip.ac.id/page/visi-misi'><span>Visi-Misi</span></a>
				</li>
				<li><a href='http://if.undip.ac.id/page/pimpinan'><span>Pimpinan</span></a>
				</li>
				<li><a href='http://if.undip.ac.id/staff'><span>Staff</span></a>
				</li>
				<li><a href='http://if.undip.ac.id/penelitian'><span>Penelitian</span></a>
				</li>
				<li><a href='http://if.undip.ac.id/pengabdian'><span>Pengabdian</span></a>
				</li>
				<li><a href='http://if.undip.ac.id/page/kerjasama'><span>Kerjasama</span></a>
				</li>
		</ul></div>
	</li>
	<li class='parent'><a href='#'><span>Akademik</span></a>
		<div><ul><li><a href='http://if.undip.ac.id/page/peraturan-akademik'><span>Peraturan Akademik</span></a>
				 </li>
				 <li><a href='http://if.undip.ac.id/page/manual-prosedur'><span>Manual Prosedur</span></a>
				</li>
				<li><a href='http://if.undip.ac.id/page/kalender-akademik'><span>Kalender Akademik</span></a>
				</li>
				<li><a href='http://if.undip.ac.id/kurikulum'><span>Kurikulum</span></a>
				</li>
				<li><a href='http://if.undip.ac.id/page/jadwal-kuliah'><span>Jadwal Kuliah</span></a>
				</li>
		</ul></div>
	</li>
	<li class='parent'><a href='#'><span>Fasilitas</span></a>
		<div><ul><li><a href='http://if.undip.ac.id/page/lab-riset'><span>Laboratorium Riset</span></a>
				</li>
				<li><a href='http://if.undip.ac.id/page/lab-layanan'><span>Laboratorium Layanan</span></a>
				</li>
				<li><a href='http://if.undip.ac.id/page/sarana-it'><span>Sarana IT</span></a>
				</li>
				<li><a href='http://if.undip.ac.id/page/fasilitas-olahraga'><span>Fasilitas Olahraga</span></a>
				</li>
				<li><a href='http://if.undip.ac.id/page/sarana-umum'><span>Sarana Umum</span></a>
				</li>
		</ul></div>
	</li>
	<li class='parent'><a href='#'><span>Kemahasiswaan</span></a>
		<div><ul>
			<li><a href='http://if.undip.ac.id/page/prestasi-mahasiswa'><span>Prestasi Mahasiswa</span></a></li>
			<li><a href='http://hm.if.undip.ac.id/'><span>Himpunan Mahasiswa</span></a></li>
			<li><a href='http://forum.if.undip.ac.id/'><span>Forum Mahasiswa</span></a></li>
			<li class='parent'><a href='http://if.undip.ac.id/page/biro-komunitas'><span>Biro dan Komunitas</span></a>
				<div>
					<ul>
						<li><a href='http://if.undip.ac.id/page/biro-komunitas#digit'><span>DIGIT</span></a></li>
						<li><a href='http://if.undip.ac.id/page/biro-komunitas#ifthen'><span>IFTHEN</span></a></li>
						<li><a href='http://if.undip.ac.id/page/biro-komunitas#osnet'><span>OS.Net</span></a></li>
						<li><a href='http://if.undip.ac.id/page/biro-komunitas#java'><span>JAVA Club</span></a></li>
						<li><a href='http://if.undip.ac.id/page/biro-komunitas#dewe'><span>DEWE</span></a></li>
						<li><a href='http://if.undip.ac.id/page/biro-komunitas#inphinity'><span>INPHINITY</span></a></li>
						<li><a href='http://if.undip.ac.id/page/biro-komunitas#blogger'><span>Blogger</span></a></li>
						<li><a href='http://if.undip.ac.id/page/biro-komunitas#ati'><span>ATI</span></a></li>
					</ul>
				</div>
			</li>
			<li><a href='#'><span>Himpunan Alumni</span></a></li>
		</ul></div>
	</li>
	<li class='parent'><a href='http://if.undip.ac.id/news'><span>Berita</span></a>
		<div><ul><li><a href='http://if.undip.ac.id/news?cat=1'><span>Akademik</span></a>
				</li>
				<li><a href='http://if.undip.ac.id/agenda'><span>Agenda</span></a>
				</li>
				<li><a href='http://if.undip.ac.id/news?cat=3'><span>Lowongan</span></a>
				</li>
		</ul></div>
	</li>
	<li><a href='http://if.undip.ac.id/galeri'><span>Galeri</span></a></li>
	<li><a href='http://if.undip.ac.id/page/kontak'><span>Kontak</span></a></li>
</ul>