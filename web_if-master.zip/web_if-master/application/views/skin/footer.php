		<div class='divclear'></div>
	</div>
</div>
<div id='site_footer'>
	<div id='site_footer_body'>
		<div id='site_footer_contact'>
			Jurusan Ilmu Komputer/Informatika Universitas Diponegoro<br>
			<img src='<?php echo base_url('/assets/images/foot_mail.png');?>' alt='Alamat:' class='img_icon'  title='Alamat'/> Jl. Prof. Soedarto, S.H. Kampus Tembalang Semarang 50275<br>
			<img src='<?php echo base_url('/assets/images/foot_phone.png');?>' alt='Telp.' class='img_icon' title='Telepon'/> (024) 70594104 
			<img src='<?php echo base_url('/assets/images/foot_email.png');?>' alt='Email:' class='img_icon' title='Email'/> <a href='mailto:if@undip.ac.id' style='color: #9ED5FF;'>if@undip.ac.id</a><br>
			<br>
			<ul class='list_link_footer'>
				<li class='first'><small>Copyright &copy; 2014 Ilmu Komputer / Informatics UNDIP</small></li>
				<li><a href='<?php echo base_url('/tentangsitus');?>'><small>tentang situs</small></a></li>
				<li><small>Page rendered in <strong>{elapsed_time}</strong> seconds</small></li>
			</ul>
			<br>
			<div class='list_link_footer'>
			<?php /*
				<!-- Start of StatCounter Code for Default Guide -->
				
				<script type="text/javascript">
					var sc_project=9644950; 
					var sc_invisible=0; 
					var sc_security="3ef79298"; 
					var scJsHost = (("https:" == document.location.protocol) ?
					"https://secure." : "http://www.");
					document.write("<sc"+"ript type='text/javascript' src='" +
					scJsHost+
					"statcounter.com/counter/counter.js'></"+"script>");
				</script>
				<noscript><div class="statcounter"><a title="hit counter"
					href="http://statcounter.com/free-hit-counter/"
					target="_blank"><img class="statcounter"
					src="http://c.statcounter.com/9644950/0/3ef79298/0/"
					alt="hit counter"></a></div></noscript>
				<!-- End of StatCounter Code for Default Guide -->
				<a href="http://statcounter.com/p9644950/?guest=1" style="font-size:11px">View My
				Stats</a>
				*/ ?>
			</div>
		</div>
	</div>
	<div class='divclear'></div>
</div>
</div><!-- end main wrapper -->

<!-- Google Analytics -->
<?php /*
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-51369435-3', 'auto');
  ga('send', 'pageview');

</script> */ ?>
</BoDy ><!-- Menghindari injeksi oleh ISP -->
</hTMl >