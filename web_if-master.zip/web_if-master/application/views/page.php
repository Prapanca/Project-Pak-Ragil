	<div id='site_content_article'>
		<h2 class='site_article_title'><?php echo $_page->f_title; ?></h2>
		<small>Diposting oleh <?php echo $_page->f_creator; ?> pada <?php echo $_page->f_date_submit; ?></small>
		<hr>
		<?php echo $_page->f_content; ?><br>
	</div>
	