<div style='text-align: center; min-height: 400px;'>
	<h2>Maaf, halaman tidak ditemukan</h2>
	<p>Jika hal ini merupakan kesalahan server, silakan laporkan kepada kami :</p>
	<p><a href='mailto:if@undip.ac.id'>if@undip.ac.id</a></p>
	<p>	<a href='<?php echo base_url('/'); ?>'>Home</a> -
		<a href='<?php echo base_url('/news'); ?>'>Berita</a> -
		<a href='<?php echo base_url('/page/sitemap'); ?>'>Sitemap</a> -
		<a href='<?php echo base_url('/page/kontak'); ?>'>Kontak</a>
	</p>
</div>