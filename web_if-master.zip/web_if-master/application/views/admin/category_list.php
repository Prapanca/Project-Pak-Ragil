<ul>
<?php foreach($_cats as $_cat) { ?>
	<li><?php echo $_cat->f_name; ?> id <?php echo $_cat->f_id; ?></li>
<?php } ?>
</ul>