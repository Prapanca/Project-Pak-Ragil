<h2>Informatics UNDIP CMS</h2>
Development Changelog
<hr>
7 Maret 2014:
<ul>
	<li>Penyempurnaan pada <span style="font-style: italic;">user previlege</span>.</li>
</ul>
21 Juli 2014<br>
<small>[Mulai Pengembangan lanjutan]</small>
<ul>
	<li>Penyempurnaan tampilan list posting (sekarang menggunakan dataTables).</li>
</ul>