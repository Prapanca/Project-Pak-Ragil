<div id='site_content_article'>
	<h2><?php echo $page_title?></h2>
	<div id='site_content_article_in'>
		<table cellpadding='5px' class='table_struktur_org'>
			<tr align='center' valign='top'>
				<td colspan=5 style='max-width:100;width:20%'><img class="photo_staff" src='/assets/images/test_banner_1.jpg'/><br>Pak Nurdin<br></td>
			</tr>
			<tr align='center' valign='top' >
				<td colspan=2><img class="photo_staff" src='/assets/images/test_banner_1.jpg'/><br>Pak Ragil<br></td>
				<td></td>
				<td colspan=2><img class="photo_staff" src='/assets/images/test_banner_1.jpg'/><br>Pak Tikno<br></td>
			</tr>
			<tr align='center' valign='top'>
				<td  style='max-width:100;width:20%'><img class="photo_staff" src='/assets/images/test_banner_2.jpg'/><br>Pak A<br></td>
				<td  style='max-width:100;width:20%'><img class="photo_staff" src='/assets/images/test_banner_2.jpg'/><br>Pak B<br></td>
				<td  style='max-width:100;width:20%'><img class="photo_staff" src='/assets/images/test_banner_2.jpg'/><br>Pak C<br></td>
				<td  style='max-width:100;width:20%'><img class="photo_staff" src='/assets/images/test_banner_2.jpg'/><br>Pak D<br></td>
				<td  style='max-width:100;width:20%'><img class="photo_staff" src='/assets/images/test_banner_2.jpg'/><br>Pak E<br></td>
			</tr>
		</table>
	</div>
</div>