<ul class='menu lavaLamp'>
	<li><a href='/'><span>Home</span></a>
	</li>
	<li><a href='#'><span>Profil</span></a>
		<div><ul><li><a href='/page/sejarah'><span>Sejarah</span></a>
				</li>
				<li><a href='/page/visi-misi'><span>Visi-Misi</span></a>
				</li>
				<li><a href='#'><span>Struktur Organisasi</span></a>
				</li>
				<li><a href='/staff'><span>Pimpinan / Staff</span></a>
				</li>
				<li><a href='#'><span>Kerjasama</span></a>
				</li>
		</ul></div>
	</li>
	<li><a href='#'><span>Akademik</span></a>
		<div><ul><li><a href='#'><span>Peraturan Akademik</span></a>
				 </li>
				 <li><a href='#'><span>Manual Prosedur</span></a>
				</li>
				<li><a href='#'><span>Kalender Akademik</span></a>
				</li>
				<li><a href='/kurikulum'><span>Kurikulum</span></a>
				</li>
				<li><a href='#'><span>Jadwal Kuliah</span></a>
				</li>
		</ul></div>
	</li>
	<li><a href='#'><span>Fasilitas</span></a>
		<div><ul><li><a href='http://labs.if.undip.ac.id/'><span>Laboratorium Riset</span></a>
				</li>
				<li><a href='http://labs.if.undip.ac.id'><span>Laboratorium Layanan</span></a>
				</li>
				<li><a href='#'><span>Sarana IT</span></a>
				</li>
				<li><a href='#'><span>Fasilitas Olahraga</span></a>
				</li>
				<li><a href='#'><span>Sarana Umum</span></a>
				</li>
		</ul></div>
	</li>
	<li><a href='#'><span>Kemahasiswaan</span></a>
		<div><ul><li><a href='#'><span>Prestasi Mahasiswa</span></a>
				</li>
				<li><a href='http://hm.if.undip.ac.id/'><span>Himpunan Mahasiswa</span></a>
				</li>
				<li><a href='#'><span>Unit Kegiatan Mahasiswa</span></a>
				</li>
				<li><a href='#'><span>Himpunan Alumni</span></a>
				</li>
		</ul></div>
	</li>
	<li><a href='#'><span>Berita</span></a>
		<div><ul><li><a href='#'><span>Pengumuman</span></a>
				</li>
				<li><a href='#'><span>Agenda</span></a>
				</li>
				<li><a href='#'><span>Lowongan</span></a>
				</li>
		</ul></div>
	</li>
	<li><a href='/page/kontak'><span>Kontak</span></a>
	</li>
	<li><a href='/admin/'><span>Administrator &raquo;</span></a>
	</li>
</ul>


  